#include "Canine.h"

Canine::Canine(string name_, int age_, string habitat_, int carnivore_): Mammal(name_, age_, habitat_, carnivore_) { };
