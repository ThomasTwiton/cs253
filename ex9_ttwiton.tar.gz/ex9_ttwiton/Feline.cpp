#include "Feline.h"

Feline::Feline(string name_, int age_, string habitat_, bool carnivore_): Mammal(name_, age_, habitat_, carnivore_) { };
