#include "HouseCat.h"
//Task 10b: Implement the class constructor
HouseCat::HouseCat(string name_, int age_, bool carnivore_) : Feline(name_, age_, "House", carnivore_){className = __FUNCTION__;};

