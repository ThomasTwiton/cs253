#include "exercise9.h"
#include "Feline.h"

#ifndef BOBCAT_H
#define BOBCAT_H

class BobCat: public Feline {
    public:
        BobCat(string name_, int age_);
};

#endif
