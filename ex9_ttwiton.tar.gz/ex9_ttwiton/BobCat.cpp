#include "BobCat.h"
//Task 10a: Implement the class constructor
BobCat::BobCat(string name_, int age_) : Feline(name_, age_, "Forest", true){className = __FUNCTION__;};
