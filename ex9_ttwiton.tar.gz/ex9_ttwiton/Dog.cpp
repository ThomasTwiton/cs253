#include "Dog.h"

Dog::Dog(string name_, int age_, string habitat_): Canine(name_, age_, habitat_, true) { className = __FUNCTION__; };
